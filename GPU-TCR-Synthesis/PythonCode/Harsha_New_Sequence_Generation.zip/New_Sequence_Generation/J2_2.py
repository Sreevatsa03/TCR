import re, os, sys, getV

def getDSeqs(seq, pal=4):
    seqs = {seq: 1}
    for i in range(len(seq)-1, pal-1, -1):
        if len(seq[:i]) < pal*2:
            seqs[seq[pal*2-len(seq[:i]):i]] = 1
            continue
        seqs[seq[:i]] = 1
    three_chew_keys = seqs.keys()
    for seq in three_chew_keys:
        if len(seq) > 1:
            for i in range(1, len(seq)+1):
                if seqs.has_key(seq[i:]):
                    seqs[seq[i:]] += 1
                else:
                    seqs[seq[i:]] = 1

    return seqs

def create_seq(num):
    NTs = ['A', 'C', 'G', 'T']
    all_poss = []
    if num > 0:
        for nt in NTs:
            if num == 1:
                all_poss.append(nt)
            else:
                rec_seq = create_seq(num - 1)
                for n in rec_seq:
                    all_poss.append(nt + n)

    return all_poss

def TdT_Addition(seq, num):
    seqs = []
    if len(seq) == 0 and num == 0:
        return [['', num, num]]
    if len(seq) == 0:
        a = create_seq(num)
        return [[c_seq, num, 0] for c_seq in a]
    if num == 0:
        return [[seq, num, num]]   
    for i in range(num, -1, -1):
        n1 = create_seq(i)
        n2 = create_seq(num-i)
        nDJ, nDJn = [], []
        if len(n1) != 0:
            for n1_seq in n1:
                if len(n2) == 0:
                    seqs.append([n1_seq + seq, i, num-i])
                else:
                    nDJ.append(n1_seq + seq)
                       
        for n2_seq in n2:
            if len(n1) != 0:
                for n1_seq in nDJ:
                    nDJn.append(n1_seq + n2_seq)
            else:
                seqs.append([seq + n2_seq, i, num-i])
        for nDJn_seq in nDJn:
            seqs.append([nDJn_seq, i, num-i])

    return seqs

            
V_info = getV.getVGene()
V_gene = V_info[1]
V_fam = V_info[0]
J_gene = 'TTTGCAAACACCGGGCAGCTCTAC' #JB2~2
J_fam = 'JB2~2'

all_d_seqs = getDSeqs('TCCCGGGACAGGGGGCGCCC')
temp = getDSeqs('TCCCGGGACTGGGGGGGCGCCC')
for seq in temp:
    if all_d_seqs.has_key(seq):
        all_d_seqs[seq] += temp[seq]
    else:
        all_d_seqs[seq] = temp[seq]
del temp

valid_sequences, loop, n_add, in_vivo = 0, 0, int(sys.argv[1]), {}

f = open('//homeA//home3//u23//krovi//Seqman_nDn//Harshfied_Seqman_nDn//seqman_H_output_files_12_26_2010//Removed_for_CDR3_Mutations//Full_Report_Redundancy_Aminotype.txt', 'r')
for line in f:
    if re.search('Full', line) or re.search('Total', line) or line == '\n':
        continue
    temp = re.sub('\n', '', line).split()
    if temp[0] == 'V4~1':
        temp[0] = 'V4'
    if str(temp[0]) == V_fam:
        if str(temp[1]) == J_fam:
            in_vivo[str(temp[5])] = 0
f.close()

for v in range(len(V_gene)+1):
    V = str(V_gene[0:len(V_gene)-v])
    for j in range(len(J_gene)+1):
        J = str(J_gene[j:len(J_gene)])
        for seq in all_d_seqs:
            for n in range(n_add, n_add+1):
                check_seqs = TdT_Addition(seq, n)
                for n_seq in check_seqs:
                    tcr = V + n_seq[0] + J
                    if in_vivo.has_key(tcr):
                        valid_sequences += all_d_seqs[seq]
                        in_vivo[tcr] += all_d_seqs[seq]                               
                    loop += 1
                    if loop%1000000 == 0:
                        print 'Loop Counter: ' + str(loop)

s = 'In-Vivo Sequences Mapped by In-Silico Sequences\n\n'
s += 'V-Gene'.center(6) + ' ' + 'J-Gene'.center(6) + ' ' + 'CDR3-Sequence'.center(72) + ' ' + 'GPU-Frequency'.center(13) + '\n'

for ntype in in_vivo:
    s += V_fam.center(6) + ' ' + J_fam.center(6) + ' ' + str(ntype).center(72) + ' ' + str(in_vivo[ntype]).center(13) + '\n'

f = open('//homeA//home3//u23//krovi//Seqman_nDn//Harshfied_Seqman_nDn//Synthesized_Sequences_for_VJ_Pairs//New_VJ_Synthesis//New_Sequence_Generation//' + V_fam + '_' + J_fam + '_' + str(n_add) + '.txt', 'w')
f.write(s)
f.close()

print 'Valid Sequences: ' + str(valid_sequences)