import re, os, sys

def create_seq(num):
    NTs = ['A', 'C', 'G', 'T']
    all_poss = []
    if num > 0:
        for nt in NTs:
            if num == 1:
                all_poss.append(nt)
            else:
                rec_seq = create_seq(num - 1)
                for n in rec_seq:
                    all_poss.append(nt + n)

    return all_poss

print create_seq(3)
