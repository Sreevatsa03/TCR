import re, os, sys, getV

'''
The getDSeqs() function generates all the various sequences that can be biologically synthesized due to chewbacks
based on a provided D-sequence.

Inputs: seq (str) --> The full length D-sequence of interest.
        pal (int) --> The number of palindromic nucleotides to include.

Outputs: seqs (dict) --> The various sequences mapped to the number of ways each can be generated. 
'''

def getDSeqs(seq, pal=4):
    seqs = {seq: 1}
    # determines all the chewbacks from the 3' end
    for i in range(len(seq)-1, pal-1, -1):
        if len(seq[:i]) < pal*2:
            seqs[seq[pal*2-len(seq[:i]):i]] = 1
            continue
        seqs[seq[:i]] = 1        
    three_chew_keys = seqs.keys()
    # determines all the chewbacks from the 5' end
    for seq in three_chew_keys:
        if len(seq) > 1:
            for i in range(1, len(seq)+1):
                if seqs.has_key(seq[i:]):
                    seqs[seq[i:]] += 1
                else:
                    seqs[seq[i:]] = 1
    return seqs

'''
The create_seq() function generates all the possible nucleotide combinations given a number of total nucleotides in a
recursive manner.

Inputs: num (int) --> The total number of nucleotides to include in the string.

Outputs: all_post (list) --> A list containing all the possible combinations of nucleotides of a given length
'''
def create_seq(num):
    NTs = ['A', 'C', 'G', 'T']
    all_poss = []    
    if num > 0:
        for nt in NTs:
            if num == 1:
                all_poss.append(nt)
            else:
                rec_seq = create_seq(num - 1)
                for n in rec_seq:
                    all_poss.append(nt + n)

    return all_poss

'''
The TdT_Addition() function generates all the possible sequences that can be generated given a certain D-sequence and
the total number of n-nucleotides to be added. They can be added on either side of the D-sequenceas long as the total
number of nucleotides added is equal to the total number of nucleotides specified as the input parameter. The n-nucleotide
sequence combinations are determined by calling the create_seq() function. 

Inputs: seq (str) --> The D-sequence to which the various n-nucleotides will be added.
        num (int) --> The total number of nucleotides to be added.

Outputs: seqs (list) --> A list of all the possible nDn sequences that can be generated given a specific D-sequence and a
                         number of nucleotides to be added. 

'''


def TdT_Addition(seq, num):
    seqs = []
    if len(seq) == 0 and num == 0:
        return [['', num, num]]
    #return empty sequence and 0 n-nucleotides on the 5' and 3' sides if seq and num == 0
    if len(seq) == 0:
        a = create_seq(num)
        return [[c_seq, num, 0] for c_seq in a]
    #return just the n-nucleotide combinations if seq == 0
    if num == 0:
        return [[seq, num, num]]
    #return just the seq if num == 0
    for i in range(num, -1, -1):
        n1 = create_seq(i)
        n2 = create_seq(num-i)
        nDJ, nDJn = [], []
        if len(n1) != 0:
            for n1_seq in n1:
                if len(n2) == 0:
                    seqs.append([n1_seq + seq, i, num-i])
                else:
                    nDJ.append(n1_seq + seq)
                       
        for n2_seq in n2:
            if len(n1) != 0:
                for n1_seq in nDJ:
                    nDJn.append(n1_seq + n2_seq)
            else:
                seqs.append([seq + n2_seq, i, num-i])
        for nDJn_seq in nDJn:
            seqs.append([nDJn_seq, i, num-i])

    return seqs


#retrieve the V and J genes/full length germline sequences that are part of the CDR3         
V_info = getV.getVGene()
V_gene = V_info[1]
V_fam = V_info[0]
J_gene = 'TTTGCAAACACAGAAGTCTTC' #JB1~1
J_fam = 'JB1~1'

#Obtain the various D sequences
all_d_seqs = getDSeqs('TCCCGGGACAGGGGGCGCCC')
D_keys = sorted(all_d_seqs.keys(), key = lambda seq: len(seq))

valid_sequences, loop, n_add = 0, 0, int(sys.argv[1])
in_vivo = {}

f = open('//homeA//home3//u23//krovi//Seqman_nDn//Harshfied_Seqman_nDn//seqman_H_output_files_12_26_2010//Removed_for_CDR3_Mutations//Full_Report_Redundancy_Aminotype.txt', 'r')
#Retrieve all the VJ sequences from the in-vivo data set for the given V and J genes
for line in f:
    if re.search('Full', line) or re.search('Total', line) or line == '\n':
        continue
    temp = re.sub('\n', '', line).split()
    if temp[0] == 'V4~1':
        temp[0] = 'V4'
    if str(temp[0]) == V_fam:
        if str(temp[1]) == J_fam:
            in_vivo[str(temp[5])] = 0
f.close()

#Determine if the concatenated sequence matches one of the in-vivo sequences and if so, increment that counter
for v in range(len(V_gene)+1):
    V = str(V_gene[0:len(V_gene)-v])
    for j in range(len(J_gene)+1):
        J = str(J_gene[j:len(J_gene)])
        for seq in all_d_seqs:
            for n in range(n_add, n_add+1):
                check_seqs = TdT_Addition(seq, n)
                for n_seq in check_seqs:
                    tcr = V + n_seq[0] + J
                    if in_vivo.has_key(tcr):
                        valid_sequences += all_d_seqs[seq]
                        in_vivo[tcr] += all_d_seqs[seq]                               
                    loop += 1
                    if loop%1000000 == 0:
                        print 'Loop Counter: ' + str(loop)

#Output the results into a file with the V-gene, J-gene, nucleotide sequence and CPU synthesis frequency
s = 'In-Vivo Sequences Mapped by In-Silico Sequences\n\n'
s += 'V-Gene'.center(6) + ' ' + 'J-Gene'.center(6) + ' ' + 'CDR3-Sequence'.center(72) + ' ' + 'CPU-Frequency'.center(13) + '\n'

for ntype in in_vivo:
    s += V_fam.center(6) + ' ' + J_fam.center(6) + ' ' + str(ntype).center(72) + ' ' + str(in_vivo[ntype]).center(13) + '\n'

f = open('//homeA//home3//u23//krovi//Seqman_nDn//Harshfied_Seqman_nDn//Synthesized_Sequences_for_VJ_Pairs//New_VJ_Synthesis//New_Sequence_Generation//' + V_fam + '_' + J_fam + '_' + str(n_add) + '.txt', 'w')
f.write(s)
f.close()

print 'Valid Sequences: ' + str(valid_sequences)
