def getVGene():
    return ['V15', 'GCCAGCAGTTTAGCGCTA']