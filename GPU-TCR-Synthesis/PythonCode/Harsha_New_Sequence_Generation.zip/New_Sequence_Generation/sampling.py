import re, os, sys, random, getV
from random import choice

g_code = { 'TTT': 'F', 'TCT': 'S', 'TAT': 'Y', 'TGT': 'C',
    'TTC': 'F', 'TCC': 'S', 'TAC': 'Y', 'TGC': 'C',
    'TTA': 'L', 'TCA': 'S', 'TAA': '*', 'TGA': '*',
    'TTG': 'L', 'TCG': 'S', 'TAG': '*', 'TGG': 'W',
    'CTT': 'L', 'CCT': 'P', 'CAT': 'H', 'CGT': 'R',
    'CTC': 'L', 'CCC': 'P', 'CAC': 'H', 'CGC': 'R',
    'CTA': 'L', 'CCA': 'P', 'CAA': 'Q', 'CGA': 'R',
    'CTG': 'L', 'CCG': 'P', 'CAG': 'Q', 'CGG': 'R',
    'ATT': 'I', 'ACT': 'T', 'AAT': 'N', 'AGT': 'S',
    'ATC': 'I', 'ACC': 'T', 'AAC': 'N', 'AGC': 'S',
    'ATA': 'I', 'ACA': 'T', 'AAA': 'K', 'AGA': 'R',
    'ATG': 'M', 'ACG': 'T', 'AAG': 'K', 'AGG': 'R',
    'GTT': 'V', 'GCT': 'A', 'GAT': 'D', 'GGT': 'G',
    'GTC': 'V', 'GCC': 'A', 'GAC': 'D', 'GGC': 'G',
    'GTA': 'V', 'GCA': 'A', 'GAA': 'E', 'GGA': 'G',
    'GTG': 'V', 'GCG': 'A', 'GAG': 'E', 'GGG': 'G'               
    }

def stopCodon(seq):
    for i in range(0, len(seq), 3):
        if g_code[seq[i:i+3]] == '*':
            return True
    return False

def getDSeqs(seq, pal=4):
    seqs = {seq: 1}
    for i in range(len(seq)-1, pal-1, -1):
        if len(seq[:i]) < pal*2:
            seqs[seq[pal*2-len(seq[:i]):i]] = 1
            continue
        seqs[seq[:i]] = 1
    three_chew_keys = seqs.keys()
    for seq in three_chew_keys:
        if len(seq) > 1:
            for i in range(1, len(seq)+1):
                if seqs.has_key(seq[i:]):
                    seqs[seq[i:]] += 1
                else:
                    seqs[seq[i:]] = 1

    return seqs

def weighted_choice_sub(weights):
    rnd = random.random() * sum(weights)
    for i, w in enumerate(weights):
        rnd -= w
        if rnd < 0:
            return i

def create_seq(num):
    NTs = ['A', 'C', 'G', 'T']
    all_poss = []
    if num > 0:
        for nt in NTs:
            if num == 1:
                all_poss.append(nt)
            else:
                rec_seq = create_seq(num - 1)
                for n in rec_seq:
                    all_poss.append(nt + n)

    return all_poss

def TdT_Addition(seq, num):
    seqs = []
    if len(seq) == 0 and num == 0:
        return [['', num, num]]
    if len(seq) == 0:
        a = create_seq(num)
        return [[c_seq, num, 0] for c_seq in a]
    if num == 0:
        return [[seq, num, num]]   
    for i in range(num, -1, -1):
        n1 = create_seq(i)
        n2 = create_seq(num-i)
        nDJ, nDJn = [], []
        if len(n1) != 0:
            for n1_seq in n1:
                if len(n2) == 0:
                    seqs.append([n1_seq + seq, i, num-i])
                else:
                    nDJ.append(n1_seq + seq)
                       
        for n2_seq in n2:
            if len(n1) != 0:
                for n1_seq in nDJ:
                    nDJn.append(n1_seq + n2_seq)
            else:
                seqs.append([seq + n2_seq, i, num-i])
        for nDJn_seq in nDJn:
            seqs.append([nDJn_seq, i, num-i])

    return seqs

            
V_info = getV.getVGene()
V_gene = V_info[1]
V_fam = V_info[0]
J_gene = 'GGAGCTCCTATGAACAGTAC' #JB2~7
J_fam = 'JB2~7'

all_d_seqs = getDSeqs('TCCCGGGACAGGGGGCGCCC')
temp = getDSeqs('TCCCGGGACTGGGGGGGCGCCC')
for seq in temp:
    if all_d_seqs.has_key(seq):
        all_d_seqs[seq] += temp[seq]
    else:
        all_d_seqs[seq] = temp[seq]
del temp

valid_sequences, loop, n_add = 0, 0, 0
in_vivo, total, all_seqs = {}, {}, []

f = open('//homeA//home3//u23//krovi//Seqman_nDn//Harshfied_Seqman_nDn//Synthesized_Sequences_for_VJ_Pairs//New_VJ_Synthesis//New_Sequence_Generation//V15_JB2_7_Nucleotypes.txt', 'r')
for line in f:
    temp = re.sub('\n', '', line).split()
    in_vivo[temp[0]] = temp[1:]
f.close()

for v in range(len(V_gene)+1):
    V = str(V_gene[0:len(V_gene)-v])
    for j in range(len(J_gene)+1):
        J = str(J_gene[j:len(J_gene)])
        for seq in all_d_seqs:
            for n in range(n_add, n_add+1):
                check_seqs = TdT_Addition(seq, n)
                for n_seq in check_seqs:
                    tcr = V + n_seq[0] + J
                    if len(tcr)%3 != 0:
                        continue
                    if stopCodon(tcr):
                        continue
                    if total.has_key(tcr):
                        total[tcr] += all_d_seqs[seq]
                    else:
                        total[tcr] = all_d_seqs[seq]
                    valid_sequences += all_d_seqs[seq]                              
                    loop += 1
                    if loop%100000 == 0:
                        print 'Loop Counter: ' + str(loop)

for ntype in total:
    temp = [ntype]*total[ntype]
    all_seqs.extend(temp)    
del total

random.shuffle(all_seqs)
shared, loop = [0]*100, 0

for i in range(100):
    m1, m2 = {}, {}
    for count in range(202):
        temp = choice(all_seqs)
        if m1.has_key(temp):
            m1[temp] += 1
        else:
            m1[temp] = 1
    for count in range(692):
        temp = choice(all_seqs)
        if m2.has_key(temp):
            m2[temp] += 1
        else:
            m2[temp] = 1

    for ntype in m1:
        if m2.has_key(ntype):
            shared[i] += 1
    
    loop += 1
    print 'Sampling Counter: ' + str(loop)

print shared
